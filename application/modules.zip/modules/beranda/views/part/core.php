<style type="text/css">
.bg {
	height: 400px;
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
}
</style>
<?php
echo link_tag('assets/css/flexslider.css');
echo link_tag('https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900');
echo link_tag('assets/css/icons/icomoon/styles.css');
echo link_tag('assets/css/icons/fontawesome/styles.min.css');
echo link_tag('assets/css/bootstrap.css');
echo link_tag('assets/css/core.css');
echo link_tag('assets/css/components.css');
echo link_tag('assets/css/colors.css');
echo link_tag('assets/css/data.css');

echo script_tag('https://cdn.ckeditor.com/4.9.2/standard-all/ckeditor.js');
echo script_tag('assets/ckfinder/ckfinder.js');
echo script_tag('assets/js/plugins/loaders/pace.min.js');
echo script_tag('assets/js/core/libraries/jquery.min.js');
echo script_tag('assets/js/core/libraries/bootstrap.min.js');
echo script_tag('https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/3.2.6/jquery.inputmask.bundle.min.js');
echo script_tag('assets/js/plugins/editors/wysihtml5/wysihtml5.min.js');
echo script_tag('assets/js/plugins/editors/wysihtml5/toolbar.js');
echo script_tag('assets/js/plugins/editors/wysihtml5/parsers.js');
echo script_tag('assets/js/plugins/editors/wysihtml5/locales/bootstrap-wysihtml5.ua-UA.js');
echo script_tag('assets/js/plugins/input-mask/jquery.inputmask.js');
echo script_tag('assets/js/plugins/loaders/blockui.min.js');
echo script_tag('assets/js/plugins/ui/nicescroll.min.js');
echo script_tag('assets/js/plugins/ui/drilldown.js');
echo script_tag('assets/js/jquery.flexslider.js');
echo script_tag('assets/js/jquery.nestable.js');

echo script_tag('assets/js/core/app.js');

echo script_tag('assets/js/plugins/forms/styling/switchery.min.js');
echo script_tag('assets/js/plugins/forms/styling/uniform.min.js');
echo script_tag('assets/js/plugins/forms/styling/switch.min.js');
echo script_tag('assets/js/plugins/tables/datatables/datatables.min.js');
echo script_tag('assets/js/plugins/forms/selects/select2.min.js');
echo script_tag('assets/js/plugins/notifications/sweet_alert.min.js');

?>