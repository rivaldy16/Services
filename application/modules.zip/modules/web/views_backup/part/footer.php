<section class="navy-section">
	<div class="container">
		Copyright 2017 - 2018 / DISKOMINFO Kota Tangerang.
	</div>
</section>