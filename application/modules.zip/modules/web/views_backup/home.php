<!-- Page container -->
<div class="page-container">

	<!-- Page content -->
	<div class="page-content">

		<!-- Main content -->
		<div class="content-wrapper">

			<!-- Main charts -->
			<div class="row">
				<div class="col-sm-12">
					<div class="flexslider">
						<ul class="slides">
							<li>
								<div class="bg" style="background-image: url('http://localhost/sistad/assets/uploads/slider/sistead-1508134313.jpeg'); ">
								</div>
							</li>
							<li>
								<div class="bg" style="background-image: url('http://localhost/sistad/assets/uploads/slider/image_square-20161025_014726.jpg'); ">
								</div>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<!-- /main charts -->

		</div>
		<!-- /main content -->

	</div>
	<!-- /page content -->

</div>
<!-- /page container -->
<script type="text/javascript">
	$('.carousel').carousel();
</script>