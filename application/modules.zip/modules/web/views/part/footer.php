<footer class="footer-area">
	<div class="container">
		<div class="row">
			<div class="col-12 col-md-12">
				<div class="footer-single-widget">
					<div class="copywrite-text mt-15">
						<img src="<?php echo base_url(); ?>assets/img/Lambang_Kota_Tangerang_Selatan.png" alt="" style="width: 60px;margin-right:15px;">
						Copyright &copy;<script>document.write(new Date().getFullYear());</script> Desa Kranggan 
					</div>
				</div>
			</div>
		</div>
	</div>
</footer>