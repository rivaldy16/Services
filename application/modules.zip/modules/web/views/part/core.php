<?php
echo link_tag('assets/style.css');
echo link_tag('https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900');
echo link_tag('assets/css/icons/icomoon/styles.css');
echo link_tag('assets/css/icons/fontawesome/styles.min.css');
echo link_tag('assets/css/bootstrap.css');	
echo link_tag('assets/css/components.css');
?>
<style type="text/css">
	.dropdown-toggle::after
	{
	  display: none !important;
	}
</style>