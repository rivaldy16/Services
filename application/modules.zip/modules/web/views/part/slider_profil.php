<div class="hero-area height-180 bg-img background-overlay" style="background-image: url(<?php echo base_url('assets/files/slider/'.$slider[0]->images_slider)?>);">
	<div class="container h-100">
		<div class="row h-100 align-items-center justify-content-center">
			<div class="col-12 col-md-8 col-lg-6">
			</div>
		</div>
	</div>
</div>